#!/usr/bin/env node

import fs from 'node:fs';
import path from 'node:path';

const inputRoot = path.resolve(process.argv[2] || process.cwd());

function readJson(file) {
  try {
    return JSON.parse(fs.readFileSync(file, 'utf8').replace(/^\uFEFF/, ''));
  } catch (error) {
    return { __error: error.message };
  }
}

function exists(file) {
  try { return fs.existsSync(file); } catch { return false; }
}

function directories(dir) {
  if (!exists(dir)) return [];
  return fs.readdirSync(dir, { withFileTypes: true })
    .filter((entry) => entry.isDirectory() && !entry.name.startsWith('.'))
    .map((entry) => entry.name)
    .sort();
}

function filesUnder(dir, depth = 5) {
  const output = [];
  function walk(current, remaining) {
    if (remaining < 0 || !exists(current)) return;
    for (const entry of fs.readdirSync(current, { withFileTypes: true })) {
      if (entry.name.startsWith('.') || ['node_modules', 'miniprogram_npm'].includes(entry.name)) continue;
      const full = path.join(current, entry.name);
      if (entry.isDirectory()) walk(full, remaining - 1);
      else if (/\.(js|mjs|cjs|ts|wxml|json)$/.test(entry.name)) output.push(full);
    }
  }
  walk(dir, depth);
  return output;
}

function countApis(files) {
  const names = [
    'wx.cloud', 'wx.getStorageSync', 'wx.setStorageSync', 'wx.removeStorageSync',
    'wx.scanCode', 'wx.getPhoneNumber', 'wx.getClipboardData', 'wx.setClipboardData',
    'wx.chooseMedia', 'wx.chooseImage', 'wx.saveImageToPhotosAlbum',
    'wx.requestSubscribeMessage', 'wx.requestPayment', 'wx.getLocation',
    'wx.addPhoneCalendar', 'wx.addPhoneRepeatCalendar'
  ];
  const counts = Object.fromEntries(names.map((name) => [name, 0]));
  for (const file of files) {
    let source;
    try { source = fs.readFileSync(file, 'utf8'); } catch { continue; }
    for (const name of names) {
      const escaped = name.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
      counts[name] += (source.match(new RegExp(escaped, 'g')) || []).length;
    }
  }
  return Object.fromEntries(Object.entries(counts).filter(([, count]) => count > 0));
}

const projectFile = path.join(inputRoot, 'project.config.json');
const projectConfig = exists(projectFile) ? readJson(projectFile) : {};
const miniRoot = path.resolve(inputRoot, projectConfig.miniprogramRoot || '.');
const appFile = path.join(miniRoot, 'app.json');
const app = exists(appFile) ? readJson(appFile) : {};
const cloudRoot = path.resolve(inputRoot, projectConfig.cloudfunctionRoot || projectConfig.cloudfunctionTemplateRoot || 'cloudfunctions');
const sourceFiles = filesUnder(miniRoot);
const ignoreEntries = Array.isArray(projectConfig.packOptions?.ignore) ? projectConfig.packOptions.ignore : [];

function isIgnored(file) {
  const relativeToProject = path.relative(inputRoot, file).replaceAll('\\', '/');
  const relativeToMiniRoot = path.relative(miniRoot, file).replaceAll('\\', '/');
  return ignoreEntries.some((entry) => {
    if (!entry || typeof entry.value !== 'string') return false;
    const value = entry.value.replaceAll('\\', '/').replace(/^\.\//, '').replace(/\/$/, '');
    const candidates = [relativeToProject, relativeToMiniRoot];
    if (entry.type === 'folder') return candidates.some((candidate) => candidate === value || candidate.startsWith(`${value}/`));
    if (entry.type === 'file') return candidates.some((candidate) => candidate === value);
    return false;
  });
}

const uploadSourceFiles = sourceFiles.filter((file) => !isIgnored(file));
const ignoredSourceFiles = sourceFiles.filter(isIgnored);

const subpackagePages = Array.isArray(app.subpackages)
  ? app.subpackages.flatMap((pkg) => (pkg.pages || []).map((page) => `${pkg.root}/${page}`))
  : [];

const report = {
  inspectedRoot: inputRoot,
  files: {
    projectConfig: exists(projectFile) ? projectFile : null,
    appJson: exists(appFile) ? appFile : null,
    miniprogramRoot: miniRoot,
    cloudfunctionRoot: exists(cloudRoot) ? cloudRoot : null
  },
  structure: {
    pages: [...(Array.isArray(app.pages) ? app.pages : []), ...subpackagePages],
    tabBarItems: app.tabBar?.list?.map((item) => item.pagePath) || [],
    cloudFunctions: directories(cloudRoot),
    scannedSourceFiles: sourceFiles.length,
    uploadSourceFiles: uploadSourceFiles.length,
    ignoredSourceFiles: ignoredSourceFiles.length
  },
  declaredCapabilities: {
    permission: app.permission || {},
    requiredPrivateInfos: app.requiredPrivateInfos || [],
    lazyCodeLoading: app.lazyCodeLoading || null
  },
  packageIgnore: {
    count: ignoreEntries.length,
    entries: ignoreEntries
  },
  observedApiCallsInUpload: countApis(uploadSourceFiles),
  observedApiCallsInIgnoredFiles: countApis(ignoredSourceFiles),
  warnings: []
};

if (!report.files.projectConfig) report.warnings.push('project.config.json was not found at the inspected root.');
if (!report.files.appJson) report.warnings.push('app.json was not found under the resolved miniprogram root.');
if (app.__error) report.warnings.push(`app.json could not be parsed: ${app.__error}`);
if (projectConfig.__error) report.warnings.push(`project.config.json could not be parsed: ${projectConfig.__error}`);
if (report.structure.pages.length === 0) report.warnings.push('No registered pages were detected.');
if (report.observedApiCallsInUpload['wx.requestPayment']) report.warnings.push('Payment API usage was detected in the upload set; review transaction category and order-center requirements.');
if (report.observedApiCallsInUpload['wx.getPhoneNumber']) report.warnings.push('Phone-number API usage was detected in the upload set; verify privacy purpose and user-triggered consent.');
if (report.observedApiCallsInUpload['wx.addPhoneCalendar'] || report.observedApiCallsInUpload['wx.addPhoneRepeatCalendar']) report.warnings.push('Phone-calendar API usage was detected in the upload set; verify that the feature and privacy declaration are intentional.');

console.log(JSON.stringify(report, null, 2));
