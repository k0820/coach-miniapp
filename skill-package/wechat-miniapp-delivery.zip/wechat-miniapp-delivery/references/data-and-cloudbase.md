# Data and CloudBase architecture

Use this reference for local-only data, CloudBase, identity, multi-device synchronization, backup, restore, or concurrent writes.

## Choose the data mode deliberately

### Local-only

Use when one device is authoritative and losing that device is an accepted risk or export/import is sufficient. Centralize storage access, version the stored shape, and make import non-destructive until validation passes.

### Cloud-backed

Use when the cloud is authoritative and temporary latency is acceptable. Keep authorization and trusted identity on the server. Do not accept a client-provided user identifier as authority.

### Local-first with cloud synchronization

Use when immediate interaction, offline use, and cross-device consistency all matter. This requires an outbox, local projection, receipts, conflict handling, and authoritative readback. A cache plus occasional upload is not a synchronization design.

## Stable data contracts

- Give every entity a stable ID.
- Keep timestamps and natural dates distinct.
- Version stored shapes and migrate old shapes explicitly.
- Keep current state separate from append-only financial or audit history.
- Snapshot display labels needed by history so later renames do not rewrite the past.
- Use key-order-independent normalization for object checksums; preserve array order.

## Cloud mutation contract

For each mutation define:

1. a stable `requestId` reused across retries of the same user action;
2. server-derived identity and authorization;
3. input whitelist that still permits documented platform-injected fields;
4. expected revision or another concurrency rule;
5. one transaction containing business changes and the receipt when possible;
6. an explicit `{ ok: false, code, details }` failure shape;
7. authoritative readback or a receipt query before retrying an uncertain request.

Do not convert deterministic rejection into retries. Distinguish timeouts/unknown delivery from validation and authorization errors.

## Local-first command states

A durable outbox item should distinguish at least:

- queued;
- sending;
- accepted but awaiting readback;
- settled;
- retryable failure;
- terminal rejection;
- stalled by dependency.

Deleting or cancelling an item may need a tombstone so the local view hides it immediately while the time slot or identity remains protected until the cloud confirms the mutation.

Only remove an outbox item when business facts are proven settled. A cloud HEAD revision greater than a local revision is not, by itself, proof that this request was applied.

## Synchronization and refresh

- Serialize writes that depend on the same revision.
- Let independent reads proceed concurrently when safe.
- After an authoritative read, schedule reconciliation so newly settled commands can leave the outbox.
- Use incremental changes only while their continuity and integrity are provable.
- Bound catch-up attempts; fall back to a full read when changes keep arriving or continuity cannot be proven.
- Version persistent caches by shape, not only by data revision.

## Sandbox isolation

Prefer separate cloud functions and collection prefixes when one CloudBase environment hosts both sandbox and production. Server-side code must reject an unexpected environment before any collection access.

Test both directions:

- sandbox commands cannot name or access production collections;
- production code cannot route to sandbox functions or caches.

## Backup and restore

A useful snapshot includes content plus metadata such as schema version, revision, checksum, byte size, and entity counts.

Separate operations:

1. create snapshot;
2. verify snapshot without mutation;
3. preview restore and conflicts;
4. create a pre-restore recovery point;
5. restore with an expected-version guard;
6. read back and compare fingerprints.

Never let an old device overwrite a newer cloud snapshot without an explicit version check and user-visible conflict decision.
