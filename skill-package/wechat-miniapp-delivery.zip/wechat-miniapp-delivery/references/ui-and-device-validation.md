# UI and real-device validation

Use this reference for redesigns, interaction feedback, sheets/modals, layout problems, or platform-specific visual behavior.

## Establish a design system before page edits

Define a small shared set of tokens:

- page and surface colors;
- primary and semantic colors;
- text hierarchy;
- type scale and line height;
- spacing scale;
- radii;
- shadows and borders;
- control heights;
- motion duration and easing.

Reuse one icon family and shared component sizes. Avoid giving every element an unrelated one-off measurement.

## Information hierarchy

For each page, identify one primary task, one primary action, and the information needed to decide. Merge duplicate routes that lead to the same task. Put secondary management functions behind a grouped row, sheet, or detail page instead of presenting every capability as a dashboard card.

Use typography, alignment, and whitespace before decorative containers. A page does not become clearer by wrapping every item in a separate card.

## Interaction feedback

Every user action should reach one visible state:

- selected;
- saving;
- saved/confirmed;
- retryable failure;
- blocked with reason.

For time selection, make the chosen date/time visually dominant and keep the confirmation action visible. If a dense selector obscures the action, collapse it after selection or transition to a confirmation state.

Do not show success before durable local save or required cloud confirmation reaches the contract chosen for that action.

## Sheets and modals

- Keep one shared sheet implementation for radius, overlay, motion, safe-area padding, and scroll locking.
- Prevent background movement while the sheet is open.
- Reserve enough bottom space for tab bars and the device home indicator.
- Keep close, back, and destructive actions visually distinct.
- Respect platform limits such as native modal button-label length.

## Validation levels

1. Source/token checks prove consistency.
2. Developer-tool rendering proves the current simulator layout.
3. Automation with real rendered coordinates proves clipping, overlap, and reachability better than handwritten geometry.
4. Real-device validation proves safe areas, native components, permission prompts, performance, and platform behavior.

When a component has failed real-device validation repeatedly despite local fixes, replace the fragile interaction with a simpler platform-appropriate design instead of adding more offsets.

## Visual review checklist

- Primary action is visible without hunting.
- Type hierarchy and line height are consistent.
- Text and controls align to a shared grid.
- Long names and accessibility font sizes do not clip.
- Empty, loading, error, and disabled states are intentional.
- Last list item remains reachable above the tab bar.
- Selection and confirmation states are unmistakable.
- Accepted pages have not changed incidentally.
