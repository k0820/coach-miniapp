# Upload, privacy review, and release

Use this reference for developer-tool uploads, privacy declarations, WeChat review, rejection repair, or publication.

## Treat artifacts as separate states

- **Development version:** uploaded from Developer Tools, available for configuration and submission.
- **Experience version:** used for invited tester validation.
- **Review version:** submitted to WeChat and waiting for a decision.
- **Release version:** published to users after review approval.

Never describe upload as submission or review approval as publication.

## Pre-upload gate

Confirm:

- version number and release note identify the intended build;
- registered pages exist in the upload package;
- package-ignore rules do not remove required code;
- unused sensitive APIs are excluded from the package if platform scanning would detect them;
- production and sandbox flags match the intended artifact;
- secrets are absent from client code;
- the package is within size limits;
- focused package tests and the final regression pass.

Source retention and upload inclusion are separate decisions. A useful maintenance file can remain in the repository while being excluded from release, provided no registered page or runtime import needs it.

## Privacy declaration

Derive declarations from the exact upload artifact and actual user flow. Search both direct calls and wrappers. Record:

- data or permission type;
- user-triggered entry point;
- purpose in plain language;
- storage/transfer behavior;
- retention and deletion route;
- third-party SDK behavior.

Do not add a capability merely to match a form, and do not declare removed behavior because an old source file still exists outside the package.

Keep purpose statements narrow. Example pattern:

> Used when the user actively performs [action] to complete [specific feature].

## Review submission

Before pressing submit, verify the version in the development row. Old approved versions may remain visible and must not be accidentally published.

Supply reviewers with a short path that reaches each gated role and key feature. State clearly when monetary amounts are records only and no online payment occurs.

After submission, verify that the intended version appears under “review version” with status “under review.” A disabled submit button or saved privacy form alone is not proof.

## Rejection handling

1. Save the exact rejection text and affected screenshot.
2. Identify whether it concerns code, package scanning, category/qualification, privacy text, or reviewer reachability.
3. Reproduce only the relevant issue.
4. Make the smallest coherent correction.
5. Re-run focused checks and one regression.
6. Upload a new version and resubmit; do not overwrite the historical explanation with an unrelated feature list.

## Publication

Review approval creates an eligible version; it does not authorize publication by itself. Confirm final authorization, publish the approved version, then verify:

- the online version number;
- cold launch on a non-developer device;
- critical login/identity path;
- one read-only business path;
- monitoring or user feedback route.

Record the final result and any platform-specific lesson in the reusable guidance only after evidence exists.
