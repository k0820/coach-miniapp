# Repository takeover and scope control

Use this reference when inheriting a mini-program repository, resuming interrupted work, or deciding whether an apparent defect is current.

## Read order

1. Repository instruction files such as `AGENTS.md`.
2. Current handoff or status file.
3. Current-state section of long-term project memory.
4. Only the reusable guidance relevant to the task.
5. Test index for the affected behavior.
6. Current source and focused tests.

Historical bug descriptions are evidence of past events, not proof of current defects. Prefer current code, current test results, and recent device evidence.

## Initial report

Before broad modification, state these eight items when the repository maintains them:

1. what the product is;
2. current lifecycle stage;
3. real-device verified behavior;
4. frozen areas;
5. current technical debt;
6. future features;
7. do-not-touch data or operations;
8. recommended next step.

## Interrupted-work recovery

When the previous operation ended unexpectedly, treat the disk as the source of truth.

1. Inspect modified times around the interruption window.
2. Classify files as complete, incomplete, untouched, or uncertain.
3. Check syntax and the nearest focused test before editing.
4. Continue only the missing portion.
5. Do not trust a UI count of generated artifacts or completed edits without checking files.

If the repository has no trustworthy Git baseline, do not use `git reset` or `checkout` as speculative recovery.

## Scope rules

- Preserve explicit product decisions even when another design seems more elegant.
- Treat accepted UI as a compatibility contract.
- Separate bug fixes from future features.
- Record deferred work rather than smuggling it into a nearby repair.
- Ask for a decision only when it changes product behavior, data risk, cost, or external publication. Resolve routine implementation choices independently.

## Environment map

Write a small table before risky work:

| Surface | Local/Sandbox/Production | Data set | Function/collection prefix | Mutations allowed |
|---|---|---|---|---|

Verify the routing in source and deployed configuration. A badge that says “test” is not proof that writes are isolated.
