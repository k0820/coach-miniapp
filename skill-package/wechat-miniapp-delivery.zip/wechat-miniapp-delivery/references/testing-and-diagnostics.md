# Testing and diagnostics

Use this reference when repairing a defect, investigating performance, or judging whether existing tests provide real evidence.

## Diagnose before patching

Convert the report into one observable statement:

> When the user performs X in state Y, expected Z does not occur; instead A occurs.

Then locate the earliest broken boundary:

1. event handler entered;
2. validation accepted;
3. state transition occurred;
4. network request was sent;
5. server accepted it;
6. authoritative data changed;
7. refreshed data reached the page;
8. rendering showed it.

Instrument or inspect these boundaries in order. “Nothing happened” does not identify which boundary failed.

## Test pyramid for mini programs

1. Pure logic tests for dates, slot conflicts, state transitions, normalization, and migration.
2. Handler-level tests that invoke the actual handler with realistic `setData` path behavior and platform callback timing.
3. Server command tests for authorization, idempotency, concurrency, and transaction results.
4. Wiring tests that load the real module rather than grep for a function name.
5. Render/automation checks for layout and navigation.
6. Real-device checks for platform permissions, modal behavior, scanning, sharing, and performance.

## Discriminating power

A green test is useful only if the targeted defect would make it fail. Demonstrate this with safe dependency injection, `require.cache`, mocks, or an isolated temporary copy. Never write a mutation into the production source tree and hope to restore it afterward.

For static tests, assert contracts and structure rather than incidental wording. If a test forbids a token everywhere, first identify legitimate locations or it will block safe code.

## Test doubles must preserve the real shape

Mocks should reproduce:

- asynchronous callback or promise timing;
- server readback shape;
- revision changes;
- failures that leave uncertain delivery;
- path-based `setData` semantics;
- identity and authorization boundaries.

A simplified fake can make two defects cancel each other and create a false green result.

## Performance investigation

Measure lanes separately: local computation, storage, network, server execution, readback, `setData`, and rendering. Count how many times the expensive work occurs. A faster single call does not help if the screen still performs the call twice.

Check whether unrelated reads are serialized behind writes or each other. Quantify both duration and call/page counts; counts expose structural duplication independent of network speed.

## Regression discipline

- Run focused checks while iterating.
- Run the complete regression once after the final relevant change.
- Re-run it only after another code/configuration change or a new unexplained failure.
- Report syntax, focused tests, full regression, simulator, and real-device evidence separately.

When a runner truncates details, execute the failing test directly instead of repeatedly running the full suite.
