---
name: wechat-miniapp-delivery
description: Plan, continue, diagnose, test, and release native WeChat Mini Programs that use local storage, CloudBase, or both. Use for repositories with app.json/project.config.json, WeChat Developer Tools, experience builds, privacy declarations, review, or release work. Do not use for generic websites or isolated media editing.
metadata:
  short-description: Safely deliver native WeChat Mini Programs from repository takeover through release
---

# WeChat Mini Program Delivery

Deliver a reviewable, testable mini program without treating production data as a debugging surface. Preserve the user's product choices and existing authorization boundaries.

## Start by classifying the task

Identify both dimensions before editing:

1. **Lifecycle:** new project, takeover, defect repair, release preparation, review rejection, or post-release maintenance.
2. **Data mode:** local-only, CloudBase-backed, or local-first with cloud synchronization.

Read the project-level instruction and handoff files first. If the repository has its own `AGENTS.md`, release checklist, frozen areas, or production-data restrictions, those rules take precedence over this skill.

Run the read-only inspector when the structure is unfamiliar:

```powershell
node scripts/inspect-miniapp.mjs <project-root>
```

The script reports structure and API usage. It does not establish business correctness or permission to deploy.

## Route to only the needed references

- For an inherited repository or interrupted task, read [references/takeover-and-scope.md](references/takeover-and-scope.md).
- For local storage, CloudBase, identity, synchronization, backup, or concurrency, read [references/data-and-cloudbase.md](references/data-and-cloudbase.md).
- For defects, test design, performance, or an unreliable existing test suite, read [references/testing-and-diagnostics.md](references/testing-and-diagnostics.md).
- For visual redesign, interaction feedback, modals, layout, or device differences, read [references/ui-and-device-validation.md](references/ui-and-device-validation.md).
- For upload, privacy declarations, review, rejection, or publication, read [references/release-and-review.md](references/release-and-review.md).

Do not load every reference automatically.

## Non-negotiable operating boundaries

- Treat **production** as real business data. Reproduce defects in an isolated sandbox unless immediate loss, duplicate charging, or continuing corruption requires a narrow freeze first.
- Keep sandbox storage, cloud collections, receipts, caches, and functions distinguishable from production. An environment label in the UI is not isolation.
- Do not deploy cloud functions, migrate data, activate a new dataset, submit review, publish, or delete remote data without authorization that covers that action.
- Do not infer that UI success means cloud success. Require a server receipt or authoritative readback for cloud mutations.
- Do not call a change device-verified until it has been checked on a real device. Automated tests and simulator checks are separate evidence levels.
- Preserve accepted UI and frozen behavior unless new evidence shows a defect. Refactoring must not silently redesign the product.
- Never test with a real customer's historical record merely because it is convenient.
- Avoid source-mutating test techniques. Inject alternatives in memory or use an isolated temporary copy.

## Delivery workflow

### 1. Establish the source of truth

Map the app root, registered pages, tab bar, cloud-function roots, storage keys, authoritative data source, and upload configuration. Resolve contradictions using current files and machine-readable artifacts before prose history.

For a takeover, report the current phase, verified behavior, frozen areas, known debt, future work, prohibited actions, and next recommendation before broad edits.

### 2. Define one behavioral contract

Write the behavior in terms of user action, visible feedback, durable state, failure state, and recovery. For data-changing actions, define:

- stable request identity;
- validation and authorization location;
- idempotency behavior;
- concurrency/version rule;
- local pending state, if any;
- authoritative completion evidence.

Keep identity fields separate from user-editable content so content expansion cannot overwrite authority.

### 3. Implement the smallest coherent change

Prefer one shared cause over page-specific patches. Centralize data access, state mappings, design tokens, and environment routing when they are the source of repeated drift. Keep UI-only changes out of business logic unless the behavior contract requires both.

### 4. Verify in increasing cost order

Use the narrowest meaningful checks first:

1. syntax and configuration parsing;
2. focused behavioral tests;
3. negative and authorization tests;
4. discriminating test evidence by safe dependency injection;
5. one complete regression run;
6. developer-tool rendering or automation when layout matters;
7. a minimal real-device scenario for platform behavior.

Do not repeatedly run the same full suite without a new change or unresolved failure.

### 5. Prepare the exact upload artifact

Audit the package, not just the working tree. Confirm page registration and package ignores agree; removed capabilities must not remain in the uploaded package if platform scanning would still detect them. Re-run focused package checks after upload configuration changes.

### 6. Separate upload, review, and release

An uploaded development version is not under review. A version under review is not released. After review passes, obtain the user's final authorization before publication unless the user already authorized automatic publication.

## Reporting standard

State:

- what changed and why;
- which environment was affected;
- what evidence passed;
- what still requires real-device or platform confirmation;
- any material risk or limitation;
- the single next action, including whether the user must do it.

Use plain language for nontechnical users. Translate terms at first use.
